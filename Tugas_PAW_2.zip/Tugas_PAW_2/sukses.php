<!DOCTYPE html>
<html lang="en">
	<head>
		<title>Sukses</title>
		<link rel="stylesheet" type="text/css" href="form.css">
	</head>
	<body>
		<h1>Registration Form</h1>
		<fieldset>	
			<legend>Person Detail</legend>
			<h3>Form submitted successfully with no errors</h3>
		</fieldset>
	</body>
</html>